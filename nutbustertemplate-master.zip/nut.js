class Nut {


  constructor (position, speed, radius, color) {
    this.position = position;
    this.speed = speed;
    this.radius = radius;
    this.color = color;
  }

  // draws a circle with correct position, color and radius
  draw () {
    let context = canvas.getContext("2d");
    context.beginPath();
    context.arc(
      this.position.x,
      this.position.y,
      this.radius,
      0, 2 * Math.PI
    );
    context.fillStyle = this.color;
    context.fill();

  }

  // move circle  and reverse direction if circle collides with border
  move () {
    this.position.x += this.speed.x;
    this.position.y += this.speed.y;
    console.log(this.position);
    if(
      this.position.x + this.radius > canvas.width ||
      this.position.x - this.radius < 0
    )
    this.speed.x *= -1; // alt bevægelse i x retningen

    if(
      this.position.y + this.radius > canvas.height ||
      this.position.y - this.radius < 0
    )
    this.speed.y *= -1; // alt bevægelse i y retningen
  }

  collide (other) { // her er delen hvor vi fik hjælp til at lave et collision program, 
    let distance = Math.abs(
      Math.sqrt(
        Math.pow(this.position.x - other.position.x, 2)
      + Math.pow(this.position.y - other.position.y, 2)
      )
    );

    let threshold = this.radius + other.radius;
    if(distance <= threshold) {
      //alert("COLLISION! " +  distance + " " + threshold); // slået fra efter det kan være irreterende at have på 24/7
      let tempx = this.speed.x;
      let tempy = this.speed.y;
      this.speed.x = other.speed.x;
      this.speed.y = other.speed.y;
      other.speed.x = tempx;
      other.speed.y = tempy; // vi har problemet at den kinda hijacker hastigheden af en anden boldt.
    }
  }

}
