console.log("Hello from Brazil");

// set up game window
canvas = document.createElement("canvas");
canvas.height = 800;
canvas.width = 1500; // gjorde banen større efter at det ville bug, efter banen var for lille
// efter bolden som man selv styrer (green) kan i virkeligheden nå uendelig hastighed, så har jeg gjort banen MEGET stor.
canvas.style.border = "5px solid gray";
canvas = document.body.appendChild(canvas);

// create a new nut object // Postion, speed, radius, color
let nut1 = new Nut({x: 300, y: 200}, {x: -5.5, y: 2.5}, 30, "Blue");
let nut2 = new Nut({x: 50, y: 200}, {x: -2.5, y: 3.5}, 40, "Red");
let nut3 = new Nut({x: 150, y: 250}, {x: 2.5, y: -5}, 25, "Yellow");
let nut4 = new Nut({x: 500, y: 200}, {x: 2.5, y: 2.5}, 70, "Orange")
let player = new Nut({x: 800, y: 200}, {x: 1, y: 1}, 30, "Green")

// refresh game 60 times each second
function gameloop () {
  //clear the canvas // hvis man fjerner eller rykker den del nedenunder, så vil bolden slet ikke findes længere.
  canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);

  //draw and move nuts
  nut1.draw();
  nut2.draw();
  nut3.draw();
  nut4.draw();
  player.draw();
  nut1.move();
  nut2.move();
  nut3.move();
  nut4.move();
  player.move();
  nut1.collide(nut2);
  nut1.collide(nut3);
  nut2.collide(nut3);
  nut4.collide(nut1);
  nut4.collide(nut2);
  nut4.collide(nut3);
  player.collide(nut1);
  player.collide(nut2);
  player.collide(nut3);
  player.collide(nut4); // den her del kunne sagtens gøres bedre
}
setInterval(gameloop, 1000/60)

function startGame() {
  myGameArea.start();
}
